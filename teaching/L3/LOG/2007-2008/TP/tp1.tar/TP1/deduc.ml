open Lib;;
open GenSousButs;;
  
deduc genSousButs;;
