X = ?;
if X<0 {
  while X<0 {
    X = X + 1;
  }; 
  Y = X;
} else { 
  Y = 0;
};
