i = 0;
k = 0;
while k < 10 {
  i = 0;
  while i < 10 {
    i = i + 1;
  };
  k = k + 1;
};

