I = 2;
J = 0;
while I + J < 21 {
  if 9 < I {
    I = I + 4;
  } else {
    I = I + 2;
    J = J + 1;
  };
};

