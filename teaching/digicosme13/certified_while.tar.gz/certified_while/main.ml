open Extracted
open Parser
open Lexer
open Print

let parse_prog file =
  let cin = open_in file in
  let lexbuf = Lexing.from_channel cin in
    try  
      let res = prog Lexer.nexttoken lexbuf in
        close_in cin; res
    with Parsing.Parse_error -> 
      failwith (Printf.sprintf "Erreur de parsing ligne %d !" !currentline) 


let args = [] 


let analyse solver print file =
  let (tab,p) = parse_prog file in
  let res =  solver p in
    Printf.printf "%s\n" (print p tab res)

let _ = 
  let file = ref "" in
    Arg.parse args (fun s -> Printf.printf "%s\n" s; file := s) "usage: while option prog";
	  analyse interval_analyse  pp_print_interval !file
	    



