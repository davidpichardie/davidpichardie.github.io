package rtl.graph;

import rtl.graph.Graph.Node;

public abstract class AbstractColorGraph {

		abstract public int color(Node n);

}
