#!/bin/sh

java -cp minijava.jar:. mj.tools.Compiler < $1
