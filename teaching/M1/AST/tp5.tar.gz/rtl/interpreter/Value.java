package rtl.interpreter;

abstract class Value {

	public abstract Value add(int i);
}
