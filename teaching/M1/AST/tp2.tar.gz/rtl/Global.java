package rtl;

public final class Global {
	public static String currentPath = "/Users/david/git/solene/ast/current/src";
}
