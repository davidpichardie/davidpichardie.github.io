import java.io.FileInputStream;

import rtl.Function;
import rtl.Program;
import rtl.ssa.ConstPropagation;
import rtl.Transform;

class Test {
	public static void main(String[] args) {
		try {
			java.io.InputStream input = System.in;

			if (args.length >= 1) {
				// On ouvre le fichier donné en paramètre.
				input = new FileInputStream(args[0]);
			}

			// On parse le programme RTL.
			Program prog = rtl.Parser.run(input);

			for (Function f: prog.functions) {
				System.out.println("ANALYSIS of " + f.headerToString());

				System.out.println("SSA INFORMATION");
				rtl.ssa.Information info = new Information(f);
				info.show();
				// Vous pouvez aussi utiliser l'implémentation de référence pour
				// tester vos résultats.
				// rtl.ssa.Information default_info = new rtl.ssa.DefaultInformation(f);
				// default_info.show();

				System.out.println("SSA CONSTANT ANALYSIS");
				ConstInference inference = new ConstInference(info);
				inference.show();
				// Vous pouvez aussi utiliser l'implémentation de référence pour
				// tester vos résultats.
				// rtl.ssa.ConstInference default_inference = new rtl.ssa.DefaultConstInference(f);
				// default_inference.show();

				ConstPropagation const_propagation = new ConstPropagation(inference);
				Transform transform = new Transform(const_propagation);
				transform.apply(f);
			}

			System.out.println("TRANSFORMED PROGRAM");
			prog.print();
		} catch(java.io.FileNotFoundException _e) {
			System.err.println("File not found");
		} catch(java.lang.SecurityException _e) {
			System.err.println("Unable to open file");
		} catch (Throwable e) {
			System.err.println("TP6 failed: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
