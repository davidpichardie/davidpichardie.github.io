import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import rtl.Function;
import rtl.Ident;
import rtl.Definition;

import rtl.Parameter;
import rtl.Operand;
import rtl.Instr;
import rtl.instr.*;
import rtl.Block;
import rtl.ssa.Phi;
import rtl.ssa.PhiArg;

/**
 * Analyse d'une fonction en forme SSA.
 */
public class Information implements rtl.ssa.Information {
	/**
	 * Les définitions associées aux variables.
	 */
	private Map<Ident, Definition> definitions;

	/**
	 * Les ensembles d'usages associés à chaque variable.
	 */
	private Map<Ident, Set<Ident>> defUses;

	/**
	 * Construction de l'analyse.
	 * @param f La fonction à analyser.
	 */
	public Information(Function f) {
		this.definitions = new Hashtable<>();
		this.defUses = new Hashtable<>();

		//TODO Construction de `definitions` et `defUses`.
	}

	/**
	 * Le domaine des variables.
	 * @return L'ensemble des variables définies dans la fonction SSA.
	 */
	public Set<Ident> domain() {
		return this.definitions.keySet();
	}

	/**
	 * Définition associée.
	 * @param  x Une variable.
	 * @return   Le type de (l'unique) définition associée à {@code x} dans la
	 *           fonction SSA.
	 */
	public Definition definition(Ident x) {
		if (!this.definitions.containsKey(x)) throw new rtl.interpreter.ErrorException("no definition found for `"+x+"'");
		return this.definitions.get(x);
	}

	/**
	 * Usages associés.
	 * @param  x Une variable.
	 * @return   L'ensemble des variables dont la définition utilise la
	 *           variable {@code x}.
	 */
	public Set<Ident> uses(Ident x) {
		if (!this.defUses.containsKey(x)) return new HashSet<>();
		return this.defUses.get(x);
	}

	/**
	 * Enregistrement d'un usage.
	 * @param def Variable définie.
	 * @param use Variable utilisée dans la définition de {@code def}.
	 */
	private void addDefUse(Ident def, Ident use) {
		if (!this.defUses.containsKey(use)) this.defUses.put(use, new HashSet<>());
		this.defUses.get(use).add(def);
	}

	/**
	 * Enregistrement d'une définition.
	 * @param def Variable définie.
	 * @param d   La définition associée à {@code def}.
	 */
	private void addDef(Ident def, Definition d) {
		if (this.definitions.containsKey(def)) throw new rtl.interpreter.ErrorException("ident "+def+" is defined twice");
		this.definitions.put(def, d);
	}
}
