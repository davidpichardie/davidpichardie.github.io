import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

import rtl.analysis.BotOrIntOrTop;
import rtl.analysis.ConstMap;
import rtl.Ident;
import rtl.Definition;
import rtl.DefinitionVisitor;
import rtl.Operand;
import rtl.OperandVisitor;
import rtl.LitInt;
import rtl.Function;
import rtl.Parameter;
import rtl.Block;
import rtl.Instr;
import rtl.instr.*;
import rtl.ssa.Phi;
import rtl.ssa.PhiArg;

/**
 * Analyse d'inférence des variables constantes dans une fonction en forme
 * SSA.
 *
 * L'objectif est d'associer à chaque variable une valeur dans
 * {@link BotOrIntOrTop}. La tâche est simplifiée par la pré-analyse de la
 * fonction SSA via une instance de la classe {@link rtl.ssa.Information}.
 */
public class ConstInference implements rtl.ssa.ConstInference {
	/**
	 * Associe à chaque variable sa valeur dans {@code BotOrIntOrTop}.
	 */
	private ConstMap map;

	/**
	 * Pré-analyse de la fonction dont on veut inférer les variables
	 * constantes.
	 */
	private rtl.ssa.Information info;

	/**
	 * Créé une nouvelle analyse d'inférence des constantes à partir d'une
	 * pré-analyse d'une fonction en forme SSA.
	 * @param info La pré-analyse de la fonction. Ces informations devraient
	 *             être suffisantes pour effectuer l'inférence des constantes.
	 */
	public ConstInference(rtl.ssa.Information info) {
		this.info = info;
		this.map = ConstMap.bottom(info.domain());

		LinkedList<Definition> workset = new LinkedList<>();
		//TODO construction de `map`.
		// Allez voir la documentation de `LinkedList`:
		// https://docs.oracle.com/en/java/javase/12/docs/api/java.base/java/util/LinkedList.html
		// En particulier la méthode `pop`.
	}

	/**
	 * Trouve la valeur associée à une variable.
	 * @param  id L'identifiant de la variable.
	 * @return    La valeur inférée de la variable.
	 */
	public BotOrIntOrTop get(Ident id) {
		return this.map.get(id);
	}

	/**
	 * Analyse la définition d'une variable.
	 * @param  definition Une définition de variable.
	 * @return            Valeur inférée associée à la définition.
	 */
	private BotOrIntOrTop evalDefinition(Definition definition) {
		return null; //TODO
	}

	/**
	 * Affiche le résultat de l'analyse.
	 */
	public void show() {
		for (Ident id : info.domain())
			System.out.println("  "+id+" = "+map.get(id));
	}
}
